﻿import { View, Text } from 'react-native';

export default function NotFound() {
  return (
    <View>
      <Text>Página não encontrada</Text>
    </View>
  );
}
