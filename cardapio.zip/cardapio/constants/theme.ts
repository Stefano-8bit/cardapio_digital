export const COLORS = {
    primary: '#FF4141',
    secondary: '#F2F2F2',
    text: '#333',
    white: '#FFF',
    green: '#4CAF50',
    red: '#F44336',
    yellow: '#FFEB3B',
  };
  